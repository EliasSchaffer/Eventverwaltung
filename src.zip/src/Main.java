//Claude

import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final String URL = "jdbc:mysql://localhost:3306/sakila";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "MYSQLPW1310&";

    private static Connection connection;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            // MySQL JDBC Treiber laden
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Verbindung zur Datenbank herstellen
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Verbindung zur Sakila-Datenbank hergestellt!");

            boolean running = true;
            while (running) {
                displayMenu();
                int choice = getUserChoice();

                switch (choice) {
                    case 1:
                        listAllCategories();
                        break;
                    case 2:
                        createCategory();
                        break;
                    case 3:
                        listAllCustomers();
                        break;
                    case 4:
                        createCustomer();
                        break;
                    case 0:
                        running = false;
                        break;
                    default:
                        System.out.println("Ungültige Auswahl. Bitte erneut versuchen.");
                }

                System.out.println(); // Leerzeile für bessere Lesbarkeit
            }

            // Verbindung schließen
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Datenbankverbindung geschlossen.");
            }

        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Treiber nicht gefunden!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Fehler bei der Datenbankverbindung!");
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    private static void displayMenu() {
        System.out.println("===== SAKILA DATENBANK MANAGER =====");
        System.out.println("1. Alle Kategorien auflisten");
        System.out.println("2. Neue Kategorie erstellen");
        System.out.println("3. Alle Kunden auflisten");
        System.out.println("4. Neuen Kunden erstellen");
        System.out.println("0. Programm beenden");
        System.out.print("Ihre Wahl: ");
    }

    private static int getUserChoice() {
        while (!scanner.hasNextInt()) {
            System.out.println("Bitte eine Zahl eingeben.");
            scanner.next();
        }
        return scanner.nextInt();
    }

    // 1. Alle Einträge der Tabelle 'category' auflisten
    private static void listAllCategories() {
        try {
            String sql = "SELECT category_id, name, last_update FROM category";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("\n===== ALLE KATEGORIEN =====");
            System.out.printf("%-5s | %-20s | %-30s\n", "ID", "Name", "Letztes Update");
            System.out.println("---------------------------------------------------");

            while (resultSet.next()) {
                int id = resultSet.getInt("category_id");
                String name = resultSet.getString("name");
                Timestamp lastUpdate = resultSet.getTimestamp("last_update");

                System.out.printf("%-5d | %-20s | %-30s\n", id, name, lastUpdate);
            }

            resultSet.close();
            statement.close();

        } catch (SQLException e) {
            System.err.println("Fehler beim Auflisten der Kategorien!");
            e.printStackTrace();
        }
    }

    // 2. Einen Eintrag in die Tabelle 'category' erstellen
    private static void createCategory() {
        try {
            scanner.nextLine(); // Zeilenumbruch konsumieren

            System.out.print("Geben Sie den Namen der neuen Kategorie ein: ");
            String categoryName = scanner.nextLine();

            String sql = "INSERT INTO category (name) VALUES (?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, categoryName);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Kategorie '" + categoryName + "' erfolgreich erstellt!");
            } else {
                System.out.println("Kategorie konnte nicht erstellt werden.");
            }

            preparedStatement.close();

        } catch (SQLException e) {
            System.err.println("Fehler beim Erstellen der Kategorie!");
            e.printStackTrace();
        }
    }

    // 3. Alle Einträge der Tabelle 'customer' auflisten
    private static void listAllCustomers() {
        try {
            String sql = "SELECT customer_id, first_name, last_name, email, active, store_id, create_date " +
                    "FROM customer";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            System.out.println("\n===== ALLE KUNDEN =====");
            System.out.printf("%-5s | %-15s | %-15s | %-30s | %-6s | %-8s | %-20s\n",
                    "ID", "Vorname", "Nachname", "Email", "Aktiv", "Store ID", "Erstelldatum");
            System.out.println("-------------------------------------------------------------------------------------");

            while (resultSet.next()) {
                int id = resultSet.getInt("customer_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String email = resultSet.getString("email");
                boolean active = resultSet.getBoolean("active");
                int storeId = resultSet.getInt("store_id");
                Timestamp createDate = resultSet.getTimestamp("create_date");

                System.out.printf("%-5d | %-15s | %-15s | %-30s | %-6b | %-8d | %-20s\n",
                        id, firstName, lastName, email, active, storeId, createDate);
            }

            resultSet.close();
            statement.close();

        } catch (SQLException e) {
            System.err.println("Fehler beim Auflisten der Kunden!");
            e.printStackTrace();
        }
    }

    // 4. Einen Eintrag in die Tabelle 'customer' erstellen
    private static void createCustomer() {
        try {
            scanner.nextLine(); // Zeilenumbruch konsumieren

            System.out.print("Vorname: ");
            String firstName = scanner.nextLine();

            System.out.print("Nachname: ");
            String lastName = scanner.nextLine();

            System.out.print("Email: ");
            String email = scanner.nextLine();

            System.out.print("Aktiv (true/false): ");
            boolean active = scanner.nextBoolean();

            System.out.print("Store ID (1 oder 2): ");
            int storeId = scanner.nextInt();

            System.out.print("Adress ID: ");
            int addressId = scanner.nextInt();

            String sql = "INSERT INTO customer (store_id, first_name, last_name, email, address_id, active) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, storeId);
            preparedStatement.setString(2, firstName);
            preparedStatement.setString(3, lastName);
            preparedStatement.setString(4, email);
            preparedStatement.setInt(5, addressId);
            preparedStatement.setBoolean(6, active);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Kunde '" + firstName + " " + lastName + "' erfolgreich erstellt!");
            } else {
                System.out.println("Kunde konnte nicht erstellt werden.");
            }

            preparedStatement.close();

        } catch (SQLException e) {
            System.err.println("Fehler beim Erstellen des Kunden!");
            e.printStackTrace();
        }
    }
}